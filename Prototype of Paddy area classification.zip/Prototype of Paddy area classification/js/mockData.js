const mockDataset = {
  "Padaviya": {
    "2016": {
      "Yala": {
        predictedArea: 3245,
        referenceArea: 3212,
        difference: 33,
        highConfidenceArea: 2890,
        mapTitle: "Sample GN 001",
        confidence: 0.91,
        gnRows: [
          { gn: "GN 001", reference: 185, predicted: 182, difference: -3, status: "Close Agreement" },
          { gn: "GN 002", reference: 250, predicted: 246, difference: -4, status: "Close Agreement" },
          { gn: "GN 003", reference: 95, predicted: 118, difference: 23, status: "Review" },
          { gn: "GN 004", reference: 310, predicted: 295, difference: -15, status: "Review" }
        ],
        dsSummary: [
          { ds: "Padaviya", predicted: 3245, reference: 3212, difference: 33 },
          { ds: "Kebithigollewa", predicted: 2860, reference: 2740, difference: 120 },
          { ds: "Mahavilachchiya", predicted: 4100, reference: 4010, difference: 90 },
          { ds: "Medawachchiya", predicted: 3385, reference: 3320, difference: 65 }
        ],
        mapPolygons: [
          { name: "Sample GN 001", area: 185, probability: 0.91, reference: 180, difference: 5, status: "Close Agreement", color: "green", coords: [[8.322, 80.452], [8.334, 80.463], [8.343, 80.451], [8.336, 80.439]] },
          { name: "Sample GN 002", area: 246, probability: 0.88, reference: 250, difference: -4, status: "Close Agreement", color: "gold", coords: [[8.348, 80.472], [8.362, 80.483], [8.372, 80.471], [8.356, 80.458]] },
          { name: "Sample GN 003", area: 118, probability: 0.66, reference: 95, difference: 23, status: "Review", color: "orange", coords: [[8.288, 80.427], [8.302, 80.437], [8.311, 80.423], [8.296, 80.411]] },
          { name: "Non-Paddy Zone", area: 0, probability: 0.13, reference: 0, difference: 0, status: "Non-Paddy", color: "gray", coords: [[8.258, 80.392], [8.399, 80.392], [8.399, 80.52], [8.258, 80.52]] }
        ]
      },
      "Maha": {
        predictedArea: 3470,
        referenceArea: 3440,
        difference: 30,
        highConfidenceArea: 3015,
        mapTitle: "Sample GN 001",
        confidence: 0.9,
        gnRows: [
          { gn: "GN 001", reference: 195, predicted: 192, difference: -3, status: "Close Agreement" },
          { gn: "GN 002", reference: 270, predicted: 264, difference: -6, status: "Close Agreement" },
          { gn: "GN 003", reference: 90, predicted: 110, difference: 20, status: "Review" }
        ],
        dsSummary: [
          { ds: "Padaviya", predicted: 3470, reference: 3440, difference: 30 },
          { ds: "Kebithigollewa", predicted: 2980, reference: 2890, difference: 90 },
          { ds: "Mahavilachchiya", predicted: 4210, reference: 4150, difference: 60 }
        ],
        mapPolygons: [
          { name: "Sample GN 001", area: 192, probability: 0.9, reference: 195, difference: -3, status: "Close Agreement", color: "green", coords: [[8.321, 80.453], [8.334, 80.462], [8.344, 80.452], [8.337, 80.44]] },
          { name: "Sample GN 002", area: 264, probability: 0.86, reference: 270, difference: -6, status: "Close Agreement", color: "gold", coords: [[8.347, 80.471], [8.362, 80.482], [8.372, 80.47], [8.356, 80.459]] },
          { name: "Sample GN 003", area: 110, probability: 0.63, reference: 90, difference: 20, status: "Review", color: "orange", coords: [[8.289, 80.426], [8.303, 80.437], [8.312, 80.424], [8.297, 80.412]] }
        ]
      }
    }
  },
  "Kebithigollewa": {
    "2016": {
      "Yala": {
        predictedArea: 2860,
        referenceArea: 2740,
        difference: 120,
        highConfidenceArea: 2510,
        mapTitle: "Sample GN 002",
        confidence: 0.83,
        gnRows: [
          { gn: "GN 001", reference: 220, predicted: 240, difference: 20, status: "Review" },
          { gn: "GN 002", reference: 185, predicted: 194, difference: 9, status: "Close Agreement" },
          { gn: "GN 003", reference: 155, predicted: 171, difference: 16, status: "Review" }
        ],
        dsSummary: [
          { ds: "Padaviya", predicted: 3245, reference: 3212, difference: 33 },
          { ds: "Kebithigollewa", predicted: 2860, reference: 2740, difference: 120 },
          { ds: "Mahavilachchiya", predicted: 4100, reference: 4010, difference: 90 },
          { ds: "Medawachchiya", predicted: 3385, reference: 3320, difference: 65 }
        ],
        mapPolygons: [
          { name: "Sample GN 001", area: 240, probability: 0.8, reference: 220, difference: 20, status: "Review", color: "orange", coords: [[8.384, 80.441], [8.397, 80.454], [8.407, 80.444], [8.394, 80.431]] },
          { name: "Sample GN 002", area: 194, probability: 0.88, reference: 185, difference: 9, status: "Close Agreement", color: "green", coords: [[8.373, 80.468], [8.388, 80.479], [8.399, 80.467], [8.385, 80.455]] },
          { name: "Sample GN 003", area: 171, probability: 0.74, reference: 155, difference: 16, status: "Review", color: "gold", coords: [[8.356, 80.424], [8.371, 80.435], [8.381, 80.422], [8.366, 80.411]] }
        ]
      }
    }
  },
  "Mahavilachchiya": {
    "2016": {
      "Yala": {
        predictedArea: 4100,
        referenceArea: 4010,
        difference: 90,
        highConfidenceArea: 3590,
        mapTitle: "Sample GN 003",
        confidence: 0.85,
        gnRows: [
          { gn: "GN 001", reference: 160, predicted: 172, difference: 12, status: "Review" },
          { gn: "GN 002", reference: 240, predicted: 250, difference: 10, status: "Review" },
          { gn: "GN 003", reference: 300, predicted: 295, difference: -5, status: "Close Agreement" }
        ],
        dsSummary: [
          { ds: "Padaviya", predicted: 3245, reference: 3212, difference: 33 },
          { ds: "Kebithigollewa", predicted: 2860, reference: 2740, difference: 120 },
          { ds: "Mahavilachchiya", predicted: 4100, reference: 4010, difference: 90 },
          { ds: "Medawachchiya", predicted: 3385, reference: 3320, difference: 65 }
        ],
        mapPolygons: [
          { name: "Sample GN 001", area: 172, probability: 0.79, reference: 160, difference: 12, status: "Review", color: "orange", coords: [[8.282, 80.318], [8.296, 80.329], [8.306, 80.318], [8.292, 80.306]] },
          { name: "Sample GN 002", area: 250, probability: 0.82, reference: 240, difference: 10, status: "Review", color: "gold", coords: [[8.307, 80.354], [8.321, 80.365], [8.33, 80.354], [8.316, 80.342]] },
          { name: "Sample GN 003", area: 295, probability: 0.9, reference: 300, difference: -5, status: "Close Agreement", color: "green", coords: [[8.323, 80.394], [8.339, 80.406], [8.349, 80.394], [8.333, 80.382]] }
        ]
      }
    }
  },
  "Medawachchiya": {
    "2016": {
      "Yala": {
        predictedArea: 3385,
        referenceArea: 3320,
        difference: 65,
        highConfidenceArea: 3040,
        mapTitle: "Sample GN 002",
        confidence: 0.86,
        gnRows: [
          { gn: "GN 001", reference: 140, predicted: 150, difference: 10, status: "Review" },
          { gn: "GN 002", reference: 190, predicted: 205, difference: 15, status: "Review" },
          { gn: "GN 003", reference: 220, predicted: 220, difference: 0, status: "Close Agreement" }
        ],
        dsSummary: [
          { ds: "Padaviya", predicted: 3245, reference: 3212, difference: 33 },
          { ds: "Kebithigollewa", predicted: 2860, reference: 2740, difference: 120 },
          { ds: "Mahavilachchiya", predicted: 4100, reference: 4010, difference: 90 },
          { ds: "Medawachchiya", predicted: 3385, reference: 3320, difference: 65 }
        ],
        mapPolygons: [
          { name: "Sample GN 001", area: 150, probability: 0.8, reference: 140, difference: 10, status: "Review", color: "orange", coords: [[8.43, 80.42], [8.443, 80.431], [8.452, 80.419], [8.439, 80.408]] },
          { name: "Sample GN 002", area: 205, probability: 0.81, reference: 190, difference: 15, status: "Review", color: "gold", coords: [[8.42, 80.45], [8.435, 80.46], [8.445, 80.449], [8.431, 80.438]] },
          { name: "Sample GN 003", area: 220, probability: 0.9, reference: 220, difference: 0, status: "Close Agreement", color: "green", coords: [[8.402, 80.47], [8.417, 80.481], [8.427, 80.469], [8.412, 80.457]] }
        ]
      }
    }
  }
};

window.mockDataset = mockDataset;
