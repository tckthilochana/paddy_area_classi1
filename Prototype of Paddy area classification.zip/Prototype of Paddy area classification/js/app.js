const defaultState = {
  dsDivision: 'Padaviya',
  year: '2016',
  season: 'Yala',
  gnDivision: 'All'
};

let map;
let mapLayerGroup;
let chartInstance = null;

function formatArea(value) {
  return `${Number(value).toLocaleString()} ha`;
}

function showToast() {
  const toast = document.getElementById('toast');
  toast.classList.add('show');
  clearTimeout(showToast.timeoutId);
  showToast.timeoutId = setTimeout(() => {
    toast.classList.remove('show');
  }, 2400);
}

function getProfile(dsDivision, year, season) {
  const dsData = window.mockDataset?.[dsDivision]?.[year]?.[season];
  if (dsData) {
    return dsData;
  }

  const fallbackDs = Object.keys(window.mockDataset || {})[0];
  return window.mockDataset[fallbackDs]['2016']['Yala'];
}

function updateCardNumbers(profile) {
  document.getElementById('predictedAreaCard').textContent = formatArea(profile.predictedArea);
  document.getElementById('referenceAreaCard').textContent = formatArea(profile.referenceArea);
  document.getElementById('differenceCard').textContent = `${profile.difference >= 0 ? '+' : ''}${profile.difference.toLocaleString()} ha`;
  document.getElementById('confidenceAreaCard').textContent = formatArea(profile.highConfidenceArea);
}

function updateComparisonTable(profile, selectedGn) {
  const tbody = document.getElementById('comparisonTableBody');
  const rows = profile.gnRows.filter((row) => {
    if (selectedGn === 'All') return true;
    return row.gn === selectedGn;
  });

  tbody.innerHTML = rows.map((row) => {
    const statusClass = row.status === 'Close Agreement' ? 'close' : 'review';
    const diffClass = Number(row.difference) >= 0 ? 'diff-review' : 'diff-close';
    return `
      <tr>
        <td>${row.gn}</td>
        <td>${row.reference}</td>
        <td>${row.predicted}</td>
        <td class="${diffClass}">${row.difference >= 0 ? '+' : ''}${row.difference}</td>
        <td><span class="status-badge ${statusClass}">${row.status}</span></td>
      </tr>
    `;
  }).join('');

  if (!rows.length) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5">No demonstration data available for the selected GN division.</td>
      </tr>
    `;
  }
}

function initializeDsSummaryChart(data) {
  const ctx = document.getElementById('dsSummaryChart');
  if (chartInstance) {
    chartInstance.destroy();
  }

  chartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: data.map((item) => item.ds),
      datasets: [
        {
          label: 'Predicted Area (ha)',
          data: data.map((item) => item.predicted),
          backgroundColor: ['#2d8d57', '#7dbb97', '#f0c77d', '#d7a85b'],
          borderRadius: 8,
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          callbacks: {
            label: (context) => `${context.dataset.label}: ${Number(context.parsed.y).toLocaleString()} ha`
          }
        }
      },
      scales: {
        y: {
          beginAtZero: false,
          ticks: {
            callback: (value) => `${Number(value).toLocaleString()}`
          }
        }
      }
    }
  });
}

function updateDsSummaryTable(data) {
  const tbody = document.getElementById('dsSummaryTableBody');
  tbody.innerHTML = data.map((item) => `
    <tr>
      <td>${item.ds}</td>
      <td>${item.predicted.toLocaleString()}</td>
      <td>${item.reference.toLocaleString()}</td>
      <td class="${item.difference >= 0 ? 'diff-review' : 'diff-close'}">${item.difference >= 0 ? '+' : ''}${item.difference.toLocaleString()}</td>
    </tr>
  `).join('');
}

function setupMap() {
  if (map) {
    map.remove();
  }

  map = L.map('map').setView([8.35, 80.45], 10);

  L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
    subdomains: 'abcd',
    maxZoom: 19
  }).addTo(map);

  mapLayerGroup = L.layerGroup().addTo(map);

  const boundaryStyle = {
    color: '#d9d9d9',
    weight: 1.2,
    opacity: 0.9,
    fillColor: '#edf1ee',
    fillOpacity: 0.5
  };

  const boundary = L.polygon([
    [8.25, 80.30],
    [8.45, 80.30],
    [8.45, 80.56],
    [8.25, 80.56]
  ], boundaryStyle).addTo(mapLayerGroup);

  boundary.bindPopup('<strong>Demonstration Area</strong><br>Anuradhapura District');
}

function renderMap(profile) {
  if (!mapLayerGroup) {
    setupMap();
  }

  mapLayerGroup.clearLayers();

  const boundary = L.polygon([
    [8.25, 80.30],
    [8.45, 80.30],
    [8.45, 80.56],
    [8.25, 80.56]
  ], {
    color: '#d9d9d9',
    weight: 1.2,
    opacity: 0.9,
    fillColor: '#edf1ee',
    fillOpacity: 0.5
  });

  boundary.addTo(mapLayerGroup);

  profile.mapPolygons.forEach((polygon) => {
    const colorMap = {
      green: '#3fae68',
      gold: '#e7c260',
      orange: '#e59a3d',
      gray: '#8d8f8d'
    };

    const layer = L.polygon(polygon.coords, {
      color: '#ffffff',
      weight: 1.5,
      fillColor: colorMap[polygon.color] || '#3fae68',
      fillOpacity: polygon.color === 'gray' ? 0.52 : 0.72,
    });

    layer.addTo(mapLayerGroup);

    layer.bindPopup(`
      <strong>${polygon.name}</strong><br>
      Predicted Paddy Area: ${formatArea(polygon.area)}<br>
      Paddy Probability: ${polygon.probability.toFixed(2)}<br>
      Reference Area: ${formatArea(polygon.reference)}<br>
      Difference: ${polygon.difference >= 0 ? '+' : ''}${polygon.difference} ha<br>
      Status: ${polygon.status}
    `);
  });

  map.fitBounds([
    [8.25, 80.30],
    [8.45, 80.56]
  ]);
}

function runClassification() {
  const district = document.getElementById('district').value;
  const dsDivision = document.getElementById('dsDivision').value;
  const year = document.getElementById('year').value;
  const season = document.getElementById('season').value;
  const gnDivision = document.getElementById('gnDivision').value;

  const profile = getProfile(dsDivision, year, season);
  updateCardNumbers(profile);
  updateComparisonTable(profile, gnDivision);
  initializeDsSummaryChart(profile.dsSummary);
  updateDsSummaryTable(profile.dsSummary);
  renderMap(profile);
  showToast();

  document.getElementById('predictedAreaCard').setAttribute('data-district', district);
  document.getElementById('predictedAreaCard').setAttribute('data-ds', dsDivision);
  document.getElementById('predictedAreaCard').setAttribute('data-season', `${year} ${season}`);
}

function initializeDefaults() {
  const dsSelect = document.getElementById('dsDivision');
  const yearSelect = document.getElementById('year');
  const seasonSelect = document.getElementById('season');
  const gnSelect = document.getElementById('gnDivision');

  dsSelect.value = defaultState.dsDivision;
  yearSelect.value = defaultState.year;
  seasonSelect.value = defaultState.season;
  gnSelect.value = defaultState.gnDivision;

  const initialProfile = getProfile(defaultState.dsDivision, defaultState.year, defaultState.season);
  updateCardNumbers(initialProfile);
  updateComparisonTable(initialProfile, defaultState.gnDivision);
  initializeDsSummaryChart(initialProfile.dsSummary);
  updateDsSummaryTable(initialProfile.dsSummary);
  setupMap();
  renderMap(initialProfile);
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('runClassification').addEventListener('click', runClassification);
  initializeDefaults();
});
